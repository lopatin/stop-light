﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Windows;
using Microsoft.Lync.Model;
using System.Net;
using System.IO;

namespace Stoplight
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

        private void getUserInformation()
        {
        }
    }
}
