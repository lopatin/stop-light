﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Lync.Model;
using System.Net;
using System.IO;

namespace Stoplight
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : Window
    {
        public void Self_ContactInformationChanged(object sender, ContactInformationChangedEventArgs e)
        {
            Contact user_as_contact = sender as Contact;

            if (e.ChangedContactInformation.Contains(ContactInformationType.ActivityId) || e.ChangedContactInformation.Contains(ContactInformationType.PersonalNote))
            {
                string stat;
                string new_activity = (string)user_as_contact.GetContactInformation(ContactInformationType.ActivityId);
                if (String.Compare(new_activity, "Free") == 0 || String.Compare(new_activity, "FreeIdle") == 0)
                {
                    ///Available
                    stat = "available";
                }
                else if (String.Compare(new_activity, "Busy") == 0 || String.Compare(new_activity, "BusyIdle") == 0 || String.Compare(new_activity, "DoNotDisturb") == 0)
                {
                    ///On-Call
                    stat = "on-call";
                }
                else if (String.Compare(new_activity, "Away") == 0 || String.Compare(new_activity, "TemporarilyAway") == 0)
                {
                    ///Away
                    stat = "away";
                }
                else
                {
                    ///Offline
                    stat = "offline";
                }
                string new_note = (string)user_as_contact.GetContactInformation(ContactInformationType.PersonalNote);
                if (new_note == null)
                {
                    new_note = "No Message";
                }
                string name = (string)user_as_contact.GetContactInformation(ContactInformationType.PrimaryEmailAddress);
                name = name.Replace("@", "");
                name = name.Replace(".", "");

                string sendout = "http://107.20.137.235:8082/set_status/" + name + "/" + stat + "/" + new_note;

                WebClient webc = new WebClient();
                webc.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                Stream data = webc.OpenRead(sendout);

                StreamReader reader = new StreamReader(data);
                string s = reader.ReadToEnd();
                Console.WriteLine(s);
                data.Close();
                reader.Close();

                Console.WriteLine(sendout);
            }
        }

        private string viewurl;
        public string VIEW_URL
        {
            get
            {
                return viewurl;
            }
            set
            {
                viewurl = value;
            }
        }

        public Window1()
        {
            LyncClient client = LyncClient.GetClient();
            Self user = client.Self;
            string stat;
            Contact user_as_contact = user.Contact;
            string activity = (string)user_as_contact.GetContactInformation(ContactInformationType.ActivityId);

            if (String.Compare(activity, "Free") == 0 || String.Compare(activity, "FreeIdle") == 0)
            {
            ///Available
               stat = "available";
            }
            else if (String.Compare(activity, "Busy") == 0 || String.Compare(activity, "BusyIdle") == 0 || String.Compare(activity, "DoNotDisturb") == 0)
            {
            ///On-Call
              stat = "on-call";
            }
            else if (String.Compare(activity, "Away") == 0 || String.Compare(activity, "TemporarilyAway") == 0 )
            {
            ///Away
              stat = "away";
            }
            else
            {
            ///Offline
              stat = "offline";
            }

            string name = (string)user_as_contact.GetContactInformation(ContactInformationType.PrimaryEmailAddress);
            name = name.Replace("@", "");
            name = name.Replace(".", "");
            viewurl = "Go to URL: http://107.20.137.235:8082/" + name;
            MessageBox.Show(viewurl);

            string note = (string)user_as_contact.GetContactInformation(ContactInformationType.PersonalNote);
            if (note == null)
            {
                note = "No Message";
            }

            string sendout = "http://107.20.137.235:8082/set_status/" + name + "/" + stat + "/" + note;

            WebClient webc = new WebClient();
            webc.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            Stream data = webc.OpenRead(sendout);

            StreamReader reader = new StreamReader(data);
            string s = reader.ReadToEnd();
            Console.WriteLine(s);
            data.Close();
            reader.Close();

            Console.WriteLine(sendout);

            InitializeComponent();
            user_as_contact.ContactInformationChanged += Self_ContactInformationChanged;
        }
    }
}
